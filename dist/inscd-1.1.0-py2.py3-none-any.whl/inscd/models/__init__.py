from inscd.models import classical, graph, neural

__all__ = [
    "classical",
    "graph",
    "neural"
]
